# Campus Lost & Found / Marketplace

A full-stack web app: campus-verified accounts, lost & found postings with
claim verification, a buy/sell/rent marketplace, real-time in-app chat, and
an admin moderation dashboard.

**Stack:** Node.js, Express, EJS (server-rendered views), SQLite (via
`better-sqlite3` — a single local file, zero setup), Socket.io for real-time
chat, Multer for image uploads, bcrypt for password hashing.

No external accounts, API keys, or cloud services are required. Everything
runs on your machine.

## Setup

```bash
npm install
cp .env.example .env
npm start
```

Then open **http://localhost:3000**.

- `.env` controls the required email domain for registration
  (`ALLOWED_DOMAIN`, default `college.edu`), the session secret, and the port.
- Register with an email ending in that domain — e.g. `you@college.edu`.
- The SQLite database file (`campus.db`) is created automatically on first run.

### Making yourself an admin

Register a normal account first, then run:

```bash
npm run make-admin -- you@college.edu
```

Log out and back in — you'll see an **Admin** link in the nav bar.

## Features implemented

- **Auth**: campus-email-only registration, bcrypt-hashed passwords,
  sessions, account suspension.
- **Lost & Found**: post lost/found items with photo, category, location,
  date; search and filter by keyword/category/type.
- **Claim verification**: finders set a private "identifying detail" when
  posting. Claimants must describe a matching detail; the finder reviews
  and approves before the claimant's contact info is revealed — no contact
  info is ever posted publicly.
- **Marketplace**: sell/rent listings with price, condition, category,
  status (available/pending/sold), search and filter.
- **Real-time chat**: Socket.io-backed messaging tied to a specific item or
  listing, so users never have to share phone numbers publicly. Falls back
  to a normal page reload if JS/sockets are unavailable (messages still
  persist to the database either way).
- **Admin moderation**: any logged-in user can flag a post; admins see a
  queue of pending flags and can remove the post or dismiss the flag, and
  can suspend/reinstate user accounts.

## Data model

```
users
 ├─ id (PK)
 ├─ name, email (unique), password_hash
 ├─ role      'student' | 'admin'
 └─ status    'active' | 'suspended'

items (lost & found posts)
 ├─ id (PK)
 ├─ user_id (FK -> users.id)
 ├─ type     'lost' | 'found'
 ├─ title, description, category, location, date_occurred, image_path
 ├─ identifying_detail   (private, server-side only)
 └─ status   'open' | 'claimed' | 'removed'

listings (marketplace posts)
 ├─ id (PK)
 ├─ user_id (FK -> users.id)
 ├─ title, description, category, price, condition
 ├─ transaction_type   'sale' | 'rent'
 ├─ image_path
 └─ status   'available' | 'pending' | 'sold' | 'removed'

claims
 ├─ id (PK)
 ├─ item_id (FK -> items.id)
 ├─ claimant_id (FK -> users.id)
 ├─ submitted_detail
 └─ status   'pending' | 'approved' | 'rejected'

conversations
 ├─ id (PK)
 ├─ item_type   'item' | 'listing'
 ├─ item_id            (FK -> items.id or listings.id, by item_type)
 ├─ initiator_id (FK -> users.id)
 └─ owner_id (FK -> users.id)

messages
 ├─ id (PK)
 ├─ conversation_id (FK -> conversations.id)
 ├─ sender_id (FK -> users.id)
 └─ content

flags
 ├─ id (PK)
 ├─ target_type   'item' | 'listing'
 ├─ target_id
 ├─ reporter_id (FK -> users.id)
 ├─ reason
 └─ status   'pending' | 'reviewed'
```

Relationships at a glance:
- One **user** → many **items**, **listings**, **claims**, **messages**, **flags**.
- One **item** → many **claims** (multiple people can claim the same found item;
  the owner approves at most one).
- One **conversation** is scoped to exactly one item *or* listing, between
  exactly two users (initiator and owner); it has many **messages**.

## Project structure

```
campus-app/
├── server.js              # app entry point, express + socket.io wiring
├── db.js                  # SQLite connection + schema (creates tables on boot)
├── middleware/auth.js      # requireLogin / requireAdmin guards
├── routes/
│   ├── auth.js             # register, login, logout
│   ├── items.js             # lost & found: list, create, detail, claim, flag
│   ├── marketplace.js       # listings: list, create, detail, status, flag
│   ├── chat.js               # conversations + messages + socket broadcast
│   └── admin.js               # flag queue, remove posts, suspend/reinstate users
├── views/                  # EJS templates (Bootstrap 5 via CDN, no build step)
├── public/                 # static CSS + uploaded images
└── scripts/make-admin.js   # CLI helper to promote a user to admin
```

## Notes / things to harden before a real deployment

- Sessions use the default in-memory store — fine for a demo/single instance,
  but swap in `connect-sqlite3` or Redis for production/multiple instances.
- Uploaded images are stored on local disk; for production, use S3/Cloudinary.
- Add rate limiting on `/register` and `/login` to slow down brute-forcing.
- The claim-approval flow currently reveals the claimant's *email* to the
  finder on approval — that's intentional (it replaces posting contact info
  publicly), but you may want to route it through the in-app chat instead.
